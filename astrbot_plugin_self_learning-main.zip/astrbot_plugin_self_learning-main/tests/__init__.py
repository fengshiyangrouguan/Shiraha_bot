"""
Test package initialization
"""
